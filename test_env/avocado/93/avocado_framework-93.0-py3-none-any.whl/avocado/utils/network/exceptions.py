class NWException(Exception):
    """
    Base Exception Class for all exceptions
    """
