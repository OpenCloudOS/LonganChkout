"""
Main entry point when called by 'python -m'.
"""

import sys

from avocado.core.main import main

if __name__ == '__main__':
    sys.exit(main())
