# The sqlite based backend is the only implementation
from .backends.sqlite import get_requirement, set_requirement
